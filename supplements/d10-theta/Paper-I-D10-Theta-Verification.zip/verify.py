"""Enclose Paper I's D10 Gram witness via theta quadrature. Python standard library only."""
import argparse
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import re

DIGITS = 120
UNIT = 10 ** DIGITS
ONE = (UNIT, UNIT)
WEIGHTS = (282, 541, 756, 910, 990, 990, 910, 756, 541, 282)


def ceil_ratio(n, d):
    return -((-n) // d)


def rational(n, d=1):
    return (n * UNIT // d, ceil_ratio(n * UNIT, d))


def add(a, b):
    return a[0] + b[0], a[1] + b[1]


def subtract(a, b):
    return a[0] - b[1], a[1] - b[0]


def scale(a, n, d=1):
    assert n >= 0 and d > 0
    return a[0] * n // d, ceil_ratio(a[1] * n, d)


def multiply(a, b):
    ends = [x*y for x in a for y in b]
    return min(ends) // UNIT, ceil_ratio(max(ends), UNIT)


def divide(a, b):
    assert b[0] > 0
    return (min(x * UNIT // y for x in a for y in b),
            max(ceil_ratio(x * UNIT, y) for x in a for y in b))


def exp_endpoint(x, upper):
    if x < -300 * UNIT:  # e^(-300) < 10^(-120)
        return int(upper)
    with localcontext() as ctx:
        ctx.prec = DIGITS + 18
        v = Decimal(f'{x}e-{DIGITS}').exp()
        exterior = v.next_plus() if upper else v.next_minus()
        n, d = exterior.as_integer_ratio()
    return ceil_ratio(n*UNIT, d) if upper else n*UNIT//d


def exponential(a):
    return exp_endpoint(a[0], False), exp_endpoint(a[1], True)


def atan_reciprocal(q):
    value = Fraction(0)
    j = 0
    while True:
        term = Fraction((-1)**j, (2*j+1)*q**(2*j+1))
        following = value + term
        if abs(term) < Fraction(1, UNIT):
            lo, hi = sorted((value, following))
            return rational(lo.numerator, lo.denominator)[0], rational(hi.numerator, hi.denominator)[1]
        value = following
        j += 1


def shell_weights():
    hist = Counter()
    for i, a in enumerate(WEIGHTS):
        for j, b in enumerate(WEIGHTS):
            hist[(i-j)**2] += a*b
    product = Counter({0: 1})
    for _ in range(10):
        result = Counter()
        for k, mass in product.items():
            for d, count in hist.items():
                result[k+d] += mass*count
        product = result
    assert product[0] == sum(x*x for x in WEIGHTS)**10
    assert sum(product.values()) == sum(WEIGHTS)**20
    assert len(product) == 739 and max(product) == 810
    return dict(sorted(product.items()))


def theta_samples(H):
    pi = subtract(scale(atan_reciprocal(5),16), scale(atan_reciprocal(239),4))
    samples = []
    for j in range(5*H//2+1):
        base = multiply(pi, exponential(rational(2*j,H)))
        value = (0, 0)
        for n in range(1,13):
            X = scale(base,n*n)
            poly = multiply(X, subtract(scale(X,2),rational(3)))
            value = add(value,multiply(exponential(subtract(rational(j,2*H), X)),poly))
        samples.append(scale(value,2 if j else 1))
    return samples


def first_cos(k,H):
    # theta^2=49k/H^2; alternating remainder after the term of degree 100.
    z = rational(49*k,H*H)
    term = ONE
    value = ONE
    for m in range(1,51):
        term = scale(multiply(term,z),1,2*m*(2*m-1))
        value = subtract(value,term) if m%2 else add(value,term)
    error = scale(multiply(term,z),1,101*102)[1]
    return value[0]-error,value[1]


def integrated(k,H,samples,error):
    c = first_cos(k,H)
    cosines = [ONE,c]
    value = add(samples[0], multiply(samples[1],c))
    for j in range(2,len(samples)):
        m = j//2
        if j%2:
            term = subtract(scale(multiply(cosines[m],cosines[m+1]),2),c)
        else:
            term = subtract(scale(multiply(cosines[m],cosines[m]),2),ONE)
        term = max(term[0],-UNIT),min(term[1],UNIT)
        assert term[0]<=term[1]
        cosines.append(term)
        value = add(value,multiply(samples[j],term))
    lo, hi = scale(value,1,H)
    return lo-error, hi+error


def analytic_errors(H):
    # See derivation in the accompanying note. These are for the full-line integral.
    alias = scale(exponential(rational(100-3*H,2)),408)[1]
    radius = scale(exponential(rational(-210)),304,420)[1]
    theta = scale(exponential(rational(-507,2)),6*152)[1]
    return {'discretization':alias,'radius_tail':radius,'theta_tail':theta}


def compute(H):
    samples = theta_samples(H)
    errors = analytic_errors(H)
    error = sum(errors.values())
    norm = integrated(0,H,samples,error)
    weights = shell_weights()
    rows = []
    total = (0,0)
    for k,count in weights.items():
        f = divide(integrated(k,H,samples,error),norm) if k else ONE
        row = scale(f,count,weights[0])
        rows.append({'k':k,'count':str(count),'lower':str(row[0]),'upper':str(row[1])})
        total = add(total,row)
    assert total[1] < 0
    return {'mesh_denominator':H,'decimal_places':DIGITS,'theta_terms':12,
            'last_radius':'5/2','integral_error_units':errors,
            'normalizer_units':list(map(str,norm)),'sum_units':list(map(str,total)),
            'shells':rows}


def compare(result, directory):
    # All enclosures above have already been calculated before either reference file is read.
    ref = json.loads((directory/'d10-rows-256.json').read_text())
    lean = (directory/'D10Rows.lean').read_text()
    def lean_list(name):
        match = re.search(r'def '+name+r' : List ℤ := \[([^\]]+)\]',lean)
        return list(map(int,re.findall(r'-?\d+',match.group(1))))
    lean_upper = lean_list('retainedUnits') + lean_list('omittedUnits')
    assert ref['scale']==10**18 and len(lean_upper)==len(ref['rows'])==len(result['shells'])==739
    for row, expected, upper in zip(result['shells'],ref['rows'],lean_upper):
        assert row['k']==expected['index'] and row['count']==expected['coefficient']
        assert upper==expected['upper']
        assert expected['lower']*UNIT <= int(row['lower'])*ref['scale']
        assert int(row['upper'])*ref['scale'] <= upper*UNIT
    result['rows_inside_reference']=len(lean_upper)
    result['reference_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest()
                                 for p in [directory/'D10Rows.lean',directory/'d10-rows-256.json']}


if __name__=='__main__':
    if not __debug__:
        raise RuntimeError('Run Python without -O so checks execute.')
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--mesh',choices=[160,192],default=160,type=int)
    cli.add_argument('--reference',type=Path)
    cli.add_argument('--output',type=Path,required=True)
    args=cli.parse_args()
    report=compute(args.mesh)
    if args.reference:
        compare(report,args.reference)
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print('mesh',args.mesh,'shells',len(report['shells']),'rows contained',report.get('rows_inside_reference'))
    print('endpoints in units of 1e-120:',report['sum_units'])
    print('analytic error units:',report['integral_error_units'])
