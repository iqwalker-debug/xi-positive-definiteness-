# A theta-integral cross-check of Paper I's ten-dimensional witness

Dated November 25, 2026. Internal computational audit for Ian Walker. This packet checks the 739 shell contributions to the concrete D10 quadratic form in *The Exact Positive-Definiteness Dimension of the Riemann Xi Function*. The paper defines the theta normalization and the finite grid. The new calculation uses the full-line theta integral, exact integer intervals, rational trigonometric bounds and Python Decimal.exp. Neither the checker nor its enclosure computation imports Arb, FLINT or a zeta/gamma implementation.

## Replay

Use Python 3 with the standard library; the supplied run used Python 3.12. Do not use -O. In the unzipped directory run:

    python -I verify.py --mesh 160 --reference reference --output rerun-160.json
    python -I verify.py --mesh 192 --reference reference --output rerun-192.json

Successful runs print 739 contained rows. The output contains lower and upper endpoints in units of 10^(-120) for every contribution and their sum. Omit --reference to generate all enclosures and prove that the sum is negative without any supplied reference. The reference files are opened only after that calculation. sha256sum -c SHA256SUMS.txt checks the distributed inputs, reports and executable. Expected files theta-160.json and theta-192.json record the full outputs.

## Provenance

The verified public Lean table is verification/lean/D10Rows.lean at b85224897e27d51141b85c98bad5173c78211dce, Git blob ae159b4b1d6442547a0e7b02c6dc78dd186078fd. The reference JSON was taken from the previously archived 256-bit Arb replay. The Lean source stores upper endpoints; the JSON stores both endpoints, the indices and counts. The code compares all four data fields as applicable. The distributed note derives the discretization and tail bounds and describes the shared assumptions. This packet did not recompile Lean, reprove D9 or ascertain publication priority. No external human referee took part.
